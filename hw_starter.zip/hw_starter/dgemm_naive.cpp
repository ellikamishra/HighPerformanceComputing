#include <omp.h>

// Naive DGEMM: C(m x n) = A(m x k) * B(k x n)
// Row-major, flattened arrays
void dgemm_naive(const double* A, const double* B, double* C,
                 int m, int n, int k) {
    // Zero C
    // parallelize with OpenMP
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            C[i * n + j] = 0.0;
        }
    }

    // TODO: Add OpenMP parallelization
   // Write your code here
}
